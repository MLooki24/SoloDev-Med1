import { useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
} from "recharts";
import {
  Plus,
  TrendingUp,
  Send,
  Bot,
  Award,
  AlertTriangle,
  CheckCircle2,
  Menu,
  X,
  MessageSquare,
  ChevronRight,
  BarChart2,
} from "lucide-react";

const SERIF = { fontFamily: "'Lora', serif" };

// ── Data ────────────────────────────────────────────────────────────────────

// Innovation volume data: x = category, y = number of entries/releases logged that quarter
// Each row is one category; each quarter is a series line
const CATEGORIES = [
  { key: "cardiac",     label: "Cardiac",     shortLabel: "Cardiac",     color: "#1d4ed8" },
  { key: "imaging",     label: "Med. Imaging", shortLabel: "Imaging",     color: "#7c3aed" },
  { key: "diabetes",    label: "Diabetes",     shortLabel: "Diabetes",    color: "#0ea5e9" },
  { key: "respiratory", label: "Respiratory",  shortLabel: "Resp.",       color: "#10b981" },
  { key: "surgical",    label: "Surg. Robotics", shortLabel: "Surgical",  color: "#f59e0b" },
  { key: "neuro",       label: "Neurology",    shortLabel: "Neuro",       color: "#ec4899" },
];

// Each data point: one record per category with entry counts per quarter
// x-axis = category label, y-axis = innovation/product entry count
const INNOVATION_DATA = [
  { category: "Cardiac",       q1: 12, q2: 14, q3: 11, q4: 17 },
  { category: "Med. Imaging",  q1:  8, q2: 11, q3: 13, q4: 15 },
  { category: "Diabetes",      q1: 15, q2: 18, q3: 16, q4: 21 },
  { category: "Respiratory",   q1:  6, q2:  7, q3:  9, q4:  8 },
  { category: "Surg. Robotics",q1:  9, q2: 13, q3: 17, q4: 23 },
  { category: "Neurology",     q1:  5, q2:  8, q3: 11, q4: 14 },
];

const QUARTERS = [
  { key: "q1", label: "Q1 2025", color: "#94a3b8" },
  { key: "q2", label: "Q2 2025", color: "#60a5fa" },
  { key: "q3", label: "Q3 2025", color: "#1d4ed8" },
  { key: "q4", label: "Q4 2025", color: "#1e3a8a" },
];

// Recent innovation/news entries per category (simulated feed)
const NEWS_ENTRIES: Record<string, { title: string; date: string; type: string }[]> = {
  "Cardiac": [
    { title: "CardioSense v5 FDA 510(k) cleared", date: "Jun 18", type: "Clearance" },
    { title: "Wearable ECG patch — 14-day continuous monitoring", date: "Jun 12", type: "Launch" },
    { title: "AI arrhythmia detection accuracy reaches 99.1%", date: "Jun 3", type: "Research" },
  ],
  "Diabetes": [
    { title: "GlucoLink Pro — real-time CGM with no calibration", date: "Jun 20", type: "Launch" },
    { title: "Closed-loop insulin delivery approved for paediatrics", date: "Jun 15", type: "Clearance" },
    { title: "Non-invasive glucose sensing via sweat analysis", date: "Jun 8", type: "Research" },
  ],
  "Surg. Robotics": [
    { title: "MicroBot SR-7 — first sub-1cm laparoscopic arm", date: "Jun 22", type: "Launch" },
    { title: "Haptic feedback surgical gloves — Phase II trial", date: "Jun 14", type: "Research" },
    { title: "Remote surgery latency below 12ms on 5G network", date: "Jun 6", type: "Research" },
  ],
};

const CHATS = [
  { id: 1, title: "CardioSense v4 vs v5", date: "Today", preview: "Cardiac monitoring device comparison..." },
  { id: 2, title: "MRI Scanner Gen 3 Review", date: "Yesterday", preview: "Analysis of image resolution gains..." },
  { id: 3, title: "Insulin Pump AFI Report", date: "Jun 20", preview: "Areas of improvement identified..." },
  { id: 4, title: "Glucose Monitor Study", date: "Jun 18", preview: "Real-time accuracy benchmarks..." },
  { id: 5, title: "Ventilator Tech Overview", date: "Jun 15", preview: "Pressure support mode analysis..." },
];

const AFI_DATA = [
  { area: "Battery Life", v4: "18 hrs", v5: "26 hrs", delta: "+44%", note: "Meets full clinical shift requirements without mid-day recharge" },
  { area: "Signal Accuracy", v4: "94.2%", v5: "98.7%", delta: "+4.5pp", note: "Significant reduction in false-positive alerts, lowering alarm fatigue" },
  { area: "Display Readability", v4: '3.5" LCD', v5: '5.1" OLED', delta: "↑", note: "Larger high-contrast OLED improves legibility for low-vision and elderly users" },
  { area: "Alert Response Time", v4: "4.2 sec", v5: "1.8 sec", delta: "−57%", note: "Critical for acute care — faster alerts meet international cardiac response guidelines" },
  { area: "Wireless Connectivity", v4: "Bluetooth 4.0", v5: "BT 5.2 + Wi-Fi", delta: "↑", note: "Direct EHR integration eliminates manual data transcription errors" },
  { area: "Device Weight", v4: "312 g", v5: "298 g", delta: "−5%", note: "Modest reduction; remains within comfortable wearable carry threshold" },
];

// ── Custom Tooltip ───────────────────────────────────────────────────────────

const InnovationTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div
      className="rounded-xl px-4 py-3 shadow-lg text-sm"
      style={{ background: "#1a2b4a", border: "1px solid rgba(255,255,255,0.1)" }}
    >
      <p className="font-semibold text-white mb-2">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey} className="flex items-center gap-2 py-0.5">
          <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: p.color }} />
          <span style={{ color: "rgba(255,255,255,0.6)" }}>{p.name}</span>
          <span className="ml-auto pl-4 font-bold text-white">{p.value} entries</span>
        </div>
      ))}
    </div>
  );
};

// ── Market Analysis View ─────────────────────────────────────────────────────

function MarketAnalysisView() {
  const [activeQuarters, setActiveQuarters] = useState<string[]>(["q3", "q4"]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const toggleQuarter = (key: string) => {
    setActiveQuarters((prev) =>
      prev.includes(key) ? (prev.length > 1 ? prev.filter((q) => q !== key) : prev) : [...prev, key]
    );
  };

  const newsItems = selectedCategory
    ? NEWS_ENTRIES[selectedCategory] ?? []
    : Object.entries(NEWS_ENTRIES).flatMap(([, v]) => v).slice(0, 5);

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      {/* Header */}
      <div className="bg-card rounded-2xl px-6 py-5 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.06)" }}>
        <div className="flex items-center gap-3 mb-1">
          <BarChart2 className="w-5 h-5" style={{ color: "#1d4ed8" }} />
          <h2 className="text-lg font-semibold text-slate-800" style={SERIF}>
            Innovation Volume by Category
          </h2>
          <span
            className="ml-auto text-xs px-2.5 py-1 rounded-full font-medium"
            style={{ background: "#eff6ff", color: "#1d4ed8" }}
          >
            2025 Tracker
          </span>
        </div>
        <p className="text-sm text-slate-500 leading-relaxed">
          Number of product launches, FDA clearances, and research entries logged per category each quarter.
          Higher lines indicate more activity in that segment.
        </p>
      </div>

      {/* Quarter toggles */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mr-1">Show:</span>
        {QUARTERS.map((q) => {
          const on = activeQuarters.includes(q.key);
          return (
            <button
              key={q.key}
              onClick={() => toggleQuarter(q.key)}
              className="text-sm px-3.5 py-1.5 rounded-full font-medium transition-all flex items-center gap-1.5"
              style={{
                background: on ? q.color : "#f1f5f9",
                color: on ? "#fff" : "#64748b",
                border: `1.5px solid ${on ? q.color : "rgba(0,0,0,0.08)"}`,
                opacity: on ? 1 : 0.65,
              }}
            >
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: on ? "rgba(255,255,255,0.7)" : q.color }} />
              {q.label}
            </button>
          );
        })}
      </div>

      {/* Line chart — x: category, y: entry count */}
      <div className="bg-card rounded-2xl px-6 py-6 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.06)" }}>
        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-4">
          Entries logged per category
        </p>
        <ResponsiveContainer width="100%" height={260}>
          <LineChart
            data={INNOVATION_DATA}
            margin={{ top: 8, right: 16, bottom: 4, left: -8 }}
            onClick={(d) => {
              if (d?.activeLabel) {
                setSelectedCategory((prev) => (prev === d.activeLabel ? null : d.activeLabel as string));
              }
            }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.05)" vertical={false} />
            <XAxis
              dataKey="category"
              tick={{ fontSize: 12, fill: "#94a3b8" }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 12, fill: "#94a3b8" }}
              axisLine={false}
              tickLine={false}
              label={{ value: "# entries", angle: -90, position: "insideLeft", offset: 12, style: { fontSize: 11, fill: "#cbd5e1" } }}
              width={52}
            />
            <Tooltip content={<InnovationTooltip />} />
            <Legend
              wrapperStyle={{ fontSize: "12px", paddingTop: "14px", color: "#64748b" }}
              formatter={(value) => QUARTERS.find((q) => q.key === value)?.label ?? value}
            />
            {QUARTERS.filter((q) => activeQuarters.includes(q.key)).map((q) => (
              <Line
                key={q.key}
                type="monotone"
                dataKey={q.key}
                name={q.key}
                stroke={q.color}
                strokeWidth={2.5}
                dot={{ r: 5, fill: q.color, strokeWidth: 2, stroke: "#fff" }}
                activeDot={{ r: 7, strokeWidth: 0 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
        <p className="text-xs text-slate-400 text-center mt-2">
          Click a category on the chart to filter the news feed below
        </p>
      </div>

      {/* Total counts row */}
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
        {INNOVATION_DATA.map((row) => {
          const total = (row.q1 ?? 0) + (row.q2 ?? 0) + (row.q3 ?? 0) + (row.q4 ?? 0);
          const isSelected = selectedCategory === row.category;
          return (
            <button
              key={row.category}
              onClick={() => setSelectedCategory(isSelected ? null : row.category)}
              className="text-left bg-card rounded-xl px-3 py-3 shadow-sm transition-all hover:shadow-md"
              style={{ border: isSelected ? "2px solid #1d4ed8" : "1px solid rgba(0,0,0,0.06)" }}
            >
              <p className="text-xl font-bold text-slate-800" style={SERIF}>{total}</p>
              <p className="text-xs text-slate-400 mt-0.5 leading-tight">{row.category}</p>
              <p className="text-xs mt-1.5 font-medium" style={{ color: "#1d4ed8" }}>2025 total</p>
            </button>
          );
        })}
      </div>

      {/* News / entry feed */}
      <div className="bg-card rounded-2xl px-6 py-5 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.06)" }}>
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-4 h-4" style={{ color: "#1d4ed8" }} />
          <h3 className="text-sm font-semibold text-slate-700" style={SERIF}>
            {selectedCategory ? `${selectedCategory} — Recent Entries` : "Latest Innovation Entries"}
          </h3>
          {selectedCategory && (
            <button
              onClick={() => setSelectedCategory(null)}
              className="ml-auto text-xs px-2.5 py-1 rounded-full"
              style={{ background: "#f1f5f9", color: "#64748b" }}
            >
              Clear filter
            </button>
          )}
        </div>
        <div className="space-y-3">
          {newsItems.length === 0 ? (
            <p className="text-sm text-slate-400">No entries logged yet for this category.</p>
          ) : (
            newsItems.map((item, i) => (
              <div
                key={i}
                className="flex items-start gap-3 p-3 rounded-xl"
                style={{ background: "#f8fafc" }}
              >
                <span
                  className="text-xs font-semibold px-2 py-1 rounded-lg flex-shrink-0 mt-0.5"
                  style={{
                    background:
                      item.type === "Clearance" ? "#f0fdf4" :
                      item.type === "Launch" ? "#eff6ff" : "#fef3c7",
                    color:
                      item.type === "Clearance" ? "#15803d" :
                      item.type === "Launch" ? "#1d4ed8" : "#92400e",
                  }}
                >
                  {item.type}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-700 leading-snug">{item.title}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{item.date}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

// ── Chat Conversation View ───────────────────────────────────────────────────

function ChatView() {
  const [input, setInput] = useState("");

  const handleTextarea = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px";
  };

  return (
    <>
      <div className="flex-1 overflow-y-auto px-6 py-8 min-h-0">
        <div className="max-w-3xl mx-auto space-y-6">
          {/* User message */}
          <div className="flex justify-end">
            <div
              className="max-w-xl px-5 py-4 rounded-2xl rounded-tr-sm text-white text-base leading-relaxed shadow-sm"
              style={{ background: "#1a2b4a" }}
            >
              Compare CardioSense v4 and v5 — what are the improvements and which version should we recommend?
            </div>
          </div>

          {/* AI response */}
          <div className="flex gap-3">
            <div
              className="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center mt-1 shadow-sm"
              style={{ background: "#eff6ff", border: "2px solid #bfdbfe" }}
            >
              <Bot className="w-5 h-5" style={{ color: "#1d4ed8" }} />
            </div>

            <div className="flex-1 space-y-5 min-w-0">
              {/* Intro */}
              <div className="bg-card rounded-2xl rounded-tl-sm px-6 py-5 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.06)" }}>
                <p className="text-base text-slate-600 leading-relaxed">
                  I&apos;ve analyzed both devices across six key clinical and operational dimensions. Below is a
                  side-by-side comparison, a detailed <strong className="text-slate-800">AFI (Areas of Improvement)</strong> breakdown,
                  and a final recommendation.
                </p>
              </div>

              {/* Side-by-side comparison */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-card rounded-2xl px-5 py-5 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.07)" }}>
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                    <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">CardioSense v4</span>
                  </div>
                  <div className="space-y-3">
                    {[["Battery","18 hours"],["Accuracy","94.2%"],["Display",'3.5" LCD'],["Alert Latency","4.2 sec"],["Connectivity","Bluetooth 4.0"],["Weight","312 g"],["FDA Clearance","510(k) 2021"]].map(([l,v])=>(
                      <div key={l}>
                        <p className="text-xs text-slate-400">{l}</p>
                        <p className="text-base font-medium text-slate-600 mt-0.5">{v}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-card rounded-2xl px-5 py-5 shadow-sm" style={{ border: "2px solid #1d4ed8" }}>
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ background: "#1d4ed8" }} />
                    <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: "#1d4ed8" }}>CardioSense v5</span>
                    <span className="ml-auto text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: "#eff6ff", color: "#1d4ed8" }}>Latest</span>
                  </div>
                  <div className="space-y-3">
                    {[
                      { l:"Battery", v:"26 hours", d:"+44%" },
                      { l:"Accuracy", v:"98.7%", d:"+4.5pp" },
                      { l:"Display", v:'5.1" OLED', d:"↑" },
                      { l:"Alert Latency", v:"1.8 sec", d:"−57%" },
                      { l:"Connectivity", v:"BT 5.2 + Wi-Fi", d:"↑" },
                      { l:"Weight", v:"298 g", d:"−5%" },
                      { l:"FDA Clearance", v:"510(k) 2024", d:null },
                    ].map(({ l, v, d }) => (
                      <div key={l} className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-xs text-slate-400">{l}</p>
                          <p className="text-base font-medium text-slate-700 mt-0.5">{v}</p>
                        </div>
                        {d && (
                          <span className="text-xs font-semibold px-1.5 py-0.5 rounded-md flex-shrink-0 mt-4" style={{ background: "#f0fdf4", color: "#15803d" }}>
                            {d}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* AFI */}
              <div className="bg-card rounded-2xl px-6 py-6 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.06)" }}>
                <div className="flex items-center gap-2.5 mb-5">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: "#fef3c7" }}>
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-slate-800" style={SERIF}>Areas of Improvement (AFI)</h3>
                    <p className="text-xs text-slate-400">v4 → v5 measured gains</p>
                  </div>
                  <span className="ml-auto text-xs px-2.5 py-1 rounded-full font-medium flex-shrink-0" style={{ background: "#fef3c7", color: "#92400e" }}>6 improvements</span>
                </div>
                <div className="space-y-2.5">
                  {AFI_DATA.map((item, i) => (
                    <div key={i} className="flex items-start gap-3 p-4 rounded-xl" style={{ background: "#f8fafc" }}>
                      <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: "#16a34a" }} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-semibold text-slate-700">{item.area}</span>
                          <span className="text-xs text-slate-400">{item.v4}</span>
                          <ChevronRight className="w-3 h-3 text-slate-300 flex-shrink-0" />
                          <span className="text-sm font-semibold" style={{ color: "#15803d" }}>{item.v5}</span>
                          <span className="text-xs font-bold px-1.5 py-0.5 rounded" style={{ background: "#dcfce7", color: "#15803d" }}>{item.delta}</span>
                        </div>
                        <p className="text-sm text-slate-500 mt-1 leading-relaxed">{item.note}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Best Pick */}
              <div className="rounded-2xl px-6 py-6 shadow-md" style={{ background: "linear-gradient(140deg, #1a2b4a 0%, #1d4ed8 100%)", border: "2px solid #3b82f6" }}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "rgba(255,255,255,0.12)" }}>
                    <Award className="w-6 h-6" style={{ color: "#fcd34d" }} />
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-widest text-white/50">Our Recommendation</p>
                    <h3 className="text-xl font-bold text-white leading-tight" style={SERIF}>CardioSense v5</h3>
                  </div>
                  <div className="ml-auto flex-shrink-0">
                    <span className="text-sm font-bold px-3 py-1.5 rounded-full" style={{ background: "#fcd34d", color: "#1c1917" }}>Best Pick</span>
                  </div>
                </div>
                <p className="text-base leading-relaxed mb-5" style={{ color: "rgba(255,255,255,0.75)" }}>
                  CardioSense v5 delivers clinically meaningful improvements across all six measured dimensions.
                  The <strong className="text-white">57% reduction in alert latency</strong> and{" "}
                  <strong className="text-white">direct EHR integration via Wi-Fi</strong> are particularly significant for acute care.
                  The larger 5.1&quot; OLED display also substantially improves usability for elderly patients in low-light conditions.
                </p>
                <div className="grid grid-cols-3 gap-3">
                  {[{ label: "Signal Accuracy", value: "98.7%" }, { label: "Alert Latency", value: "1.8 sec" }, { label: "Battery Life", value: "26 hrs" }].map((s) => (
                    <div key={s.label} className="rounded-xl px-4 py-3 text-center" style={{ background: "rgba(255,255,255,0.1)" }}>
                      <p className="text-xl font-bold text-white" style={SERIF}>{s.value}</p>
                      <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.5)" }}>{s.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Follow-up chips */}
              <div className="flex flex-wrap gap-2 pt-1">
                {["Show cost comparison", "Export AFI report", "Compare with competitor devices"].map((s) => (
                  <button key={s} className="text-sm px-4 py-2 rounded-full border font-medium transition-all hover:bg-secondary" style={{ borderColor: "rgba(29,78,216,0.3)", color: "#1d4ed8", background: "#eff6ff" }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Input */}
      <div className="flex-shrink-0 px-6 py-5 border-t" style={{ background: "rgba(240,237,232,0.9)", backdropFilter: "blur(8px)", borderColor: "rgba(0,0,0,0.07)" }}>
        <div className="max-w-3xl mx-auto">
          <div className="flex items-end gap-3 bg-card rounded-2xl px-5 py-4 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.09)" }}>
            <textarea
              value={input}
              onChange={handleTextarea}
              placeholder="Ask about technology comparisons, market trends, or device improvements..."
              className="flex-1 resize-none bg-transparent text-base text-slate-700 placeholder-slate-400 outline-none leading-relaxed"
              rows={1}
              style={{ minHeight: "28px", maxHeight: "120px" }}
            />
            <button
              className="w-11 h-11 rounded-xl flex items-center justify-center text-white transition-all hover:brightness-110 flex-shrink-0"
              style={{ background: input.trim() ? "#1d4ed8" : "#cbd5e1" }}
              aria-label="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
          <p className="text-center text-xs text-slate-400 mt-2.5">
            MedTrend AI provides analysis based on submitted context only — always verify findings with clinical sources.
          </p>
        </div>
      </div>
    </>
  );
}

// ── App ──────────────────────────────────────────────────────────────────────

type Tab = { type: "chat"; id: number } | { type: "market" };

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>({ type: "chat", id: 1 });
  const [openTabs, setOpenTabs] = useState<Tab[]>([{ type: "chat", id: 1 }]);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const openMarketTab = () => {
    const exists = openTabs.some((t) => t.type === "market");
    if (!exists) setOpenTabs((prev) => [...prev, { type: "market" }]);
    setActiveTab({ type: "market" });
  };

  const openChatTab = (id: number) => {
    const exists = openTabs.some((t) => t.type === "chat" && t.id === id);
    if (!exists) setOpenTabs((prev) => [...prev, { type: "chat", id }]);
    setActiveTab({ type: "chat", id });
  };

  const closeTab = (tab: Tab, e: React.MouseEvent) => {
    e.stopPropagation();
    const remaining = openTabs.filter((t) =>
      tab.type === "market" ? t.type !== "market" : !(t.type === "chat" && t.id === (tab as any).id)
    );
    setOpenTabs(remaining);
    const isActive =
      tab.type === "market"
        ? activeTab.type === "market"
        : activeTab.type === "chat" && activeTab.id === (tab as any).id;
    if (isActive && remaining.length > 0) setActiveTab(remaining[remaining.length - 1]);
  };

  const tabLabel = (tab: Tab) => {
    if (tab.type === "market") return "Market Analysis";
    return CHATS.find((c) => c.id === tab.id)?.title ?? "Chat";
  };

  const isActive = (tab: Tab) =>
    tab.type === "market"
      ? activeTab.type === "market"
      : activeTab.type === "chat" && activeTab.id === (tab as any).id;

  const headerTitle = () => {
    if (activeTab.type === "market") return "Market Analysis";
    return CHATS.find((c) => c.id === activeTab.id)?.title ?? "Chat";
  };

  const headerSub = () => {
    if (activeTab.type === "market") return "Global MedTech segment activity trends";
    return "Cardiac monitoring device — AFI & recommendation report";
  };

  return (
    <div className="h-screen flex overflow-hidden bg-background" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* ── LEFT SIDEBAR ── */}
      <aside
        className="flex flex-col flex-shrink-0 border-r border-white/10 transition-all duration-300"
        style={{ width: sidebarOpen ? "288px" : "0px", minWidth: sidebarOpen ? "288px" : "0px", overflow: "hidden", background: "#1a2b4a" }}
      >
        {/* Logo */}
        <div className="px-5 pt-6 pb-5 border-b border-white/10 flex-shrink-0">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "#1d4ed8" }}>
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-white font-semibold text-base leading-tight" style={SERIF}>MedTrend AI</p>
              <p className="text-xs mt-0.5" style={{ color: "#64748b" }}>Market Intelligence</p>
            </div>
          </div>
          <button
            className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-white text-base font-medium transition-all hover:brightness-110"
            style={{ background: "#1d4ed8" }}
          >
            <Plus className="w-5 h-5" />
            New Analysis
          </button>
        </div>

        {/* Scrollable list — chats + market analysis item */}
        <div className="flex-1 overflow-y-auto px-3 py-4 min-h-0">
          <p className="text-xs font-semibold uppercase tracking-widest px-2 mb-2 flex items-center gap-2" style={{ color: "#475569" }}>
            <MessageSquare className="w-3.5 h-3.5" />
            Recent Chats
          </p>

          <div className="space-y-1 mb-4">
            {CHATS.map((chat) => {
              const active = activeTab.type === "chat" && activeTab.id === chat.id;
              return (
                <button
                  key={chat.id}
                  onClick={() => openChatTab(chat.id)}
                  className="w-full text-left px-3 py-3.5 rounded-xl transition-all"
                  style={{
                    background: active ? "rgba(255,255,255,0.12)" : "transparent",
                    border: active ? "1px solid rgba(255,255,255,0.15)" : "1px solid transparent",
                  }}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate leading-tight" style={{ color: active ? "#f1f5f9" : "#94a3b8" }}>
                        {chat.title}
                      </p>
                      <p className="text-xs mt-1 truncate leading-tight" style={{ color: "#475569" }}>
                        {chat.preview}
                      </p>
                    </div>
                    <span className="text-xs flex-shrink-0" style={{ color: "#475569" }}>{chat.date}</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Divider */}
          <div className="mx-2 border-t border-white/8 mb-3" />

          {/* Market Analysis — same size as a chat item */}
          <p className="text-xs font-semibold uppercase tracking-widest px-2 mb-2 flex items-center gap-2" style={{ color: "#475569" }}>
            <BarChart2 className="w-3.5 h-3.5" />
            Insights
          </p>
          <button
            onClick={openMarketTab}
            className="w-full text-left px-3 py-3.5 rounded-xl transition-all"
            style={{
              background: activeTab.type === "market" ? "rgba(255,255,255,0.12)" : "transparent",
              border: activeTab.type === "market" ? "1px solid rgba(255,255,255,0.15)" : "1px solid transparent",
            }}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate leading-tight" style={{ color: activeTab.type === "market" ? "#f1f5f9" : "#94a3b8" }}>
                  Market Analysis
                </p>
                <p className="text-xs mt-1 truncate leading-tight" style={{ color: "#475569" }}>
                  6 categories · launches &amp; clearances
                </p>
              </div>
              <TrendingUp className="w-3.5 h-3.5 flex-shrink-0 mt-1" style={{ color: "#38bdf8" }} />
            </div>
          </button>
        </div>
      </aside>

      {/* ── MAIN PANEL ── */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header
          className="flex-shrink-0 border-b"
          style={{ background: "rgba(240,237,232,0.9)", backdropFilter: "blur(8px)", borderColor: "rgba(0,0,0,0.07)" }}
        >
          {/* Tab bar */}
          <div className="flex items-center gap-1 px-4 pt-3 overflow-x-auto">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 rounded-lg hover:bg-black/6 transition-colors flex-shrink-0 mr-1"
              aria-label="Toggle sidebar"
            >
              {sidebarOpen ? <X className="w-4 h-4 text-slate-500" /> : <Menu className="w-4 h-4 text-slate-500" />}
            </button>

            {openTabs.map((tab) => {
              const active = isActive(tab);
              return (
                <button
                  key={tab.type === "market" ? "market" : `chat-${(tab as any).id}`}
                  onClick={() => setActiveTab(tab)}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-t-xl text-sm font-medium transition-all flex-shrink-0 group"
                  style={{
                    background: active ? "#ffffff" : "rgba(0,0,0,0.04)",
                    color: active ? "#1e293b" : "#64748b",
                    borderTop: active ? "2px solid #1d4ed8" : "2px solid transparent",
                    marginBottom: active ? "-1px" : "0",
                  }}
                >
                  {tab.type === "market" ? (
                    <BarChart2 className="w-3.5 h-3.5 flex-shrink-0" style={{ color: active ? "#1d4ed8" : "#94a3b8" }} />
                  ) : (
                    <MessageSquare className="w-3.5 h-3.5 flex-shrink-0" style={{ color: active ? "#1d4ed8" : "#94a3b8" }} />
                  )}
                  <span className="max-w-[140px] truncate">{tabLabel(tab)}</span>
                  {openTabs.length > 1 && (
                    <span
                      onClick={(e) => closeTab(tab, e)}
                      className="w-4 h-4 rounded flex items-center justify-center opacity-0 group-hover:opacity-100 hover:bg-black/10 transition-all flex-shrink-0"
                    >
                      <X className="w-3 h-3" />
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Context line */}
          <div className="px-6 py-3 flex items-center gap-3">
            <div className="flex-1 min-w-0">
              <h1 className="text-base font-semibold text-slate-800 truncate" style={SERIF}>{headerTitle()}</h1>
              <p className="text-xs text-slate-500 truncate">{headerSub()}</p>
            </div>
            <span className="text-xs px-3 py-1.5 rounded-full font-medium flex-shrink-0" style={{ background: "#eff6ff", color: "#1d4ed8" }}>
              MedTrend AI
            </span>
          </div>
        </header>

        {/* Tab content */}
        {activeTab.type === "market" ? (
          <div className="flex-1 overflow-y-auto px-6 py-8 min-h-0">
            <MarketAnalysisView />
          </div>
        ) : (
          <ChatView />
        )}
      </div>
    </div>
  );
}
