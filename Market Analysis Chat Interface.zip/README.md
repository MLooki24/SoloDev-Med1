
  # Market Analysis Chat Interface

  This is a code bundle for Market Analysis Chat Interface. The original project is available at https://www.figma.com/design/yvN0FDskpahe9qywIzbvKJ/Market-Analysis-Chat-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  